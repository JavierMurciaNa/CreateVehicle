Descripción:

Este proyecto crea una plataforma interna para definir un catálogo de vehículos. El proyecto incluye:

Clases para diferentes tipos de vehículos (coche, camión, yate y motocicleta).
Clases para el motor y el consumo de combustible.
Atributos para cada clase, como modelo, año, consumo de gasolina, chasis, etc.
Vehículo con sus atributos.
Cálculo del consumo de combustible real
